/* Name: Paul Helske
 * Date: 11/20/2023
 */

import java.io.FileNotFoundException;
import javafx.scene.layout.*;
import javafx.scene.paint.*;
import javafx.scene.text.*;
import javafx.scene.control.*;
import javafx.scene.*;
import javafx.geometry.*;
import javafx.application.*;
import javafx.stage.Stage;

public class ShowDeck extends Application {

	
	public void start(Stage primaryStage) throws FileNotFoundException {
		
		CardDeck deck = null;

		try {
			deck = new CardDeck();
		} catch (FileNotFoundException ex) {
			ex.printStackTrace();
		}
		System.out.println(deck.toString());

		double cardX = 1000 / 13;
		double cardY = 400 / 4;

		Group cards = new Group();
		for (int i = 0; i < 52; i++) {
			if (i < 13) {
				deck.deck.get(i).view.setX(20 + (i * cardX));
			}
			else if (12 < i && i < 26) {
				deck.deck.get(i).view.setX(0 + ((i - 13) * cardX));
				deck.deck.get(i).view.setY(cardY);
			}
			else if (25 < i && i < 39) {
				deck.deck.get(i).view.setX(20 + ((i - 26) * cardX));
				deck.deck.get(i).view.setY(cardY * 2);
			}
			else if (38 < i) {
				deck.deck.get(i).view.setX(0 + ((i - 39) * cardX));
				deck.deck.get(i).view.setY(cardY * 3);
			}
			cards.getChildren().add(deck.deck.get(i).view);
			System.out.println(deck.deck.get(i).getName());
		}
		
		Button btCards = new Button("SHUFFLE CARDS");
		btCards.setAlignment(Pos.CENTER);
		buttonSetup(btCards, Color.PALEVIOLETRED);
		
		btCards.setOnAction(e -> {
			CardDeck deck1 = null;
			try {
				deck1 = new CardDeck();
			} catch (FileNotFoundException ex) {
				ex.printStackTrace();
			}
			System.out.println(deck1.toString());
			deck1.shuffleDeck();
			
			Group cards1 = new Group();
			for (int i = 0; i < 52; i++) {
				if (i < 13) {
					deck1.deck.get(i).view.setX(20 + (i * cardX));
				}
				else if (12 < i && i < 26) {
					deck1.deck.get(i).view.setX(0 + ((i - 13) * cardX));
					deck1.deck.get(i).view.setY(cardY);
				}
				else if (25 < i && i < 39) {
					deck1.deck.get(i).view.setX(20 + ((i - 26) * cardX));
					deck1.deck.get(i).view.setY(cardY * 2);
				}
				else if (38 < i) {
					deck1.deck.get(i).view.setX(0 + ((i - 39) * cardX));
					deck1.deck.get(i).view.setY(cardY * 3);
				}
				cards1.getChildren().add(deck1.deck.get(i).view);
				System.out.println(deck1.deck.get(i).getName());
			}
			VBox vBox = new VBox(10);
			vBox.getChildren().addAll(cards1, btCards);
			vBox.setBackground(new Background(new BackgroundFill(Color.DARKOLIVEGREEN,
					CornerRadii.EMPTY, Insets.EMPTY)));
			vBox.setPadding(new Insets(22));
			Scene scene1 = new Scene(vBox, 1050, 500);
			
			primaryStage.setScene(scene1);
			primaryStage.show();
			
		});
		
		VBox vBox = new VBox(10);
		vBox.getChildren().addAll(cards, btCards);
		vBox.setBackground(new Background(new BackgroundFill(Color.DARKOLIVEGREEN,
				CornerRadii.EMPTY, Insets.EMPTY)));
		vBox.setPadding(new Insets(22));
		Scene scene = new Scene(vBox, 1050, 500);
		
		primaryStage.setScene(scene);
		primaryStage.show();
	}
	public static void main(String[] args) {
		launch (args);
	}
	private void buttonSetup(Button bt, Color color) {
		bt.setPrefSize(150, 50);
		new Font(14);
		bt.setFont(Font.font("Tahoma", FontWeight.BOLD, FontPosture.REGULAR, 14.0));
		bt.setBackground(new Background(new BackgroundFill(color,
				CornerRadii.EMPTY, Insets.EMPTY)));
		bt.setMaxSize(180, 50);
		bt.setMinSize(130, 50);
	}
	
}
