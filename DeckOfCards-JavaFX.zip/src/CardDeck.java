/* Name: Paul Helske
 * Date: 10/17/2023
 */

import java.io.*;
import java.util.*;

public class CardDeck extends GameCard {

	public List<GameCard> deck = null;
	public int deckSize;

	public CardDeck() throws FileNotFoundException {
		deck = createDeck();
		deckSize = deck.size();
	}

	public String toString() {
		String string = "";
		if (deck != null) {
			for (int i = 0; i < deck.size(); i++) {
				string += deck.get(i).toString();
				
			}
		} else return new String("BINGO");
		return string;
		
	}
	public List<GameCard> createDeck() throws FileNotFoundException {
		List<GameCard> deck = new ArrayList<GameCard>();

		for (int i = 0; i < 52; i++) {
			deck.add(new GameCard());
		}
		for (int i = 0; i < 4; i++) {
			for (int j = 1; j < 14; j++) {
				int cardNumber;
				switch (i) {
				case 0: 
					cardNumber = j - 1; 
					deck.get(cardNumber).setName("Spade" + j);
					deck.get(cardNumber).setSuit("Spade");
					deck.get(cardNumber).setNumber(j);
					deck.get(cardNumber).setImage("Cards/spade" + j + ".png");

					break;
				case 1: 
					cardNumber = j + 12;
					deck.get(cardNumber).setName("Club" + j);
					deck.get(cardNumber).setSuit("Club");
					deck.get(cardNumber).setNumber(j);
					deck.get(cardNumber).setImage("Cards/club" + j + ".png");

					break;
				case 2: 
					cardNumber = j + 25;
					deck.get(cardNumber).setName("Heart" + j);
					deck.get(cardNumber).setSuit("Heart");
					deck.get(cardNumber).setNumber(j);
					deck.get(cardNumber).setImage("Cards/heart" + j + ".png");

					break;
				case 3: 
					cardNumber = j + 38;
					deck.get(cardNumber).setName("Diamond" + j);
					deck.get(cardNumber).setSuit("Diamond");
					deck.get(cardNumber).setNumber(j);
					deck.get(cardNumber).setImage("Cards/diamond" + j + ".png");

					break;
				}
			}
		}
		return deck;
	}
	public List<GameCard> shuffleDeck(){
		Collections.shuffle(deck);
		return deck;
	}
	public List<GameCard> drawCards(int cards){
		List<GameCard> draw = new ArrayList<GameCard>();
		
		for (int i = 0; i < cards; i++) draw.add(deck.get(i));
		
		return draw;
	}
}
