/* Name: Paul Helske
 * Date: 10/17/2023
 */

import javafx.scene.image.*;
import javafx.scene.image.Image;
import java.io.*;

public class GameCard{
	public Image img;
	public ImageView view = new ImageView(img);
	public String Suit;
	public int number;
	public String name;
	double cardW = 1000 / 13.5;
	double cardH = 500 / 5;

	public GameCard() {

	}
	public GameCard(String name1) {
		name = name1;
	}
	public void setName(String name1) {
		name = name1;
	}
	public String getName() {
		return name;
	}
	public void setSuit(String Suit) {
		this.Suit = Suit;
	}
	public String getSuit() {
		return Suit;
	}
	public void setNumber(int Number1) {
		number = Number1;
	}
	public int getNumber() {
		return number;
	}
	public void setImage(String location) throws FileNotFoundException {
		
		img = new Image(new FileInputStream(location));
		view = new ImageView(img);
		view.setFitHeight(cardH - 10);
		view.setFitWidth(cardW - 10);
	}
	public String toString() {
		return new String("\nName: " + name + "\nSuit: " + Suit + 
				"\nRank: " + number + "\n");
	}
	

}